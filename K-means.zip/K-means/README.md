# K-means_Clustering-Simulation
Simulation of K-means Clustering algorithm using P5.JS

## Overview
I have created the simulation of K-means Clustering algorithm using P5.JS graphics library. 
<br>
<br>
User can insert the data-points as well as cluster centroids on canvas at runtime and simulate how the cluster centroids will converge to centre of respective cluster. 
<br>
<br>
sketch.js contains the core logic for the simulation.
