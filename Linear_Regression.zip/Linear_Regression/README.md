# Linear_Regression_Simulation

## Overview
I have created the simulation of Linear Regression algorithm using P5.JS graphics library.
<br>
<br>
User can insert the data-points on canvas at runtime and accordingly the bestfit line would change its parameters.
<br>
<br>
Gradient Descent algorithm is implemented to minimize the cost function associated with Linear Regression.
<br>
<br>
**sketch.js** contains the core logic for the simulation.
