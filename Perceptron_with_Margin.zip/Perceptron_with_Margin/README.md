# Perceptron_with_Margin
Simulation of Perceptron Algorithm using P5.JS

## Overview
I have created the simulation of Perceptron algorithm for Binary Classification using P5.JS graphics library. 
<br>
<br>
User can insert the data-points belonging to two classes as well as change the **Learning Rate** and **Threshold or Margin** on canvas at runtime using Sliders and simulate how the Linear Separater converges to classify the given data. 
<br>
<br>
sketch.js contains the core logic for the simulation.
